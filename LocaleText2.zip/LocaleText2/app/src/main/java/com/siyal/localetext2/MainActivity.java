package com.siyal.localetext2;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    // Default quantity is 1.
    private int mInputQuantity = 1;

    // Get the number format for the user-selected locale.
    private NumberFormat mNumberFormat = NumberFormat.getInstance();

    // Add a TAG for reporting an exception with the entered quantity.
    private static final String TAG = MainActivity.class.getSimpleName();

    // Fixed price in U.S. dollars and cents: ten cents.
    private double mPrice = 0.10;

    // Approximate exchange rates for France (FR) and Israel (IW).
    private double mFrExchangeRate = 0.93; // 0.93 euros = $1.
    private double mIwExchangeRate = 3.61; // 3.61 new shekels = $1.
    private double mPkExchangeRate = 150; // 150 pkr = $1.


    // Get the currency format for the user-selected locale.
    private NumberFormat mCurrencyFormat = NumberFormat.getCurrencyInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showHelp();
            }
        });

        // Get the current date.
        final Date myDate = new Date();
        // Add 5 days in milliseconds to create the expiration date.
        final long expirationDate = myDate.getTime() + TimeUnit.DAYS.toMillis(5);
        // Set the expiration date as the date to display.
        myDate.setTime(expirationDate);

        // Format the date for the locale.
        //The DateFormat.getDateInstance() method gets the default formatting style for the user's selected language and locale. The DateFormat
        // format() method formats a date string.
        String myFormattedDate = DateFormat.getDateInstance().format(myDate);
        // Display the formatted date.
        TextView expirationDateView = (TextView) findViewById(R.id.date);
        expirationDateView.setText(myFormattedDate);

        // Set up the price and currency format.
        String myFormattedPrice;
        // Get the country code for the user-selected locale.
        final String deviceLocale = Locale.getDefault().getCountry();
        Log.d("Checking: ", deviceLocale);
        // If country code is France or Israel, calculate price
        // with exchange rate and change to the country's currency format.
        if (deviceLocale.equals("FR")) {
            // Calculate mPrice in euros.
            mPrice *= mFrExchangeRate;
            // Use the user-chosen locale's currency format
            myFormattedPrice = mCurrencyFormat.format(mPrice);
        }
        else if(deviceLocale.equals("IL")){
            // Calculate mPrice in new shekels.
            mPrice *= mIwExchangeRate;
            // Use the user-chosen locale's currency format
            myFormattedPrice = mCurrencyFormat.format(mPrice);
        }
        else if(deviceLocale.equals("PK")){
            // Calculate mPrice in new shekels.
            mPrice *= mPkExchangeRate;
            // Use the user-chosen locale's currency format
            myFormattedPrice = mCurrencyFormat.format(mPrice);
        }
        else {
            // mPrice is the same (based on U.S. dollar).
            // Use the currency format for the U.S.
            mCurrencyFormat = NumberFormat.getCurrencyInstance(Locale.US);
            myFormattedPrice = mCurrencyFormat.format(mPrice);
        }

        // Show the price string.
        TextView localePrice = (TextView) findViewById(R.id.price);
        localePrice.setText(myFormattedPrice);

        // Get the EditText view for the entered quantity.
        final EditText enteredQuantity = (EditText) findViewById(R.id.quantity);

        // Add an OnEditorActionListener to the EditText view.
        //The listener defines callbacks to be invoked when an action is performed on the editor. In this case, when the user taps the Done key,
        // it triggers the EditorInfo.IME_ACTION_DONE action, and the callback closes the keyboard.
        enteredQuantity.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if(actionId == EditorInfo.IME_ACTION_DONE){
                    // Close the keyboard.
                    InputMethodManager inputMethodManager = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    inputMethodManager.hideSoftInputFromWindow(v.getWindowToken(), 0);

                    // Parse string in view v to a number.
                    try {
                        // Use the number format for the locale.
                        mInputQuantity = mNumberFormat.parse(v.getText().toString()).intValue();
                        v.setError(null);
                    } catch (ParseException e) {
                        Log.e(TAG, Log.getStackTraceString(e));
                        v.setError(getText(R.string.enter_number));
                        return false;
                    }

                    // Convert to string using locale's number format.
                    String myFormattedQuantity = mNumberFormat.format(mInputQuantity);
                    // Show the locale-formatted quantity.
                    v.setText(myFormattedQuantity);

                    // TODO: Homework: Calculate the total amount
                    // from price and quantity.
                    double mTotalAmount = mPrice * mInputQuantity;

                    // TODO: Homework: Use currency format for
                    // France (FR) or Israel (IL).
                    String myFormattedTotalAmount;
                    if (deviceLocale.equals("FR") || deviceLocale.equals("IL") || deviceLocale.equals("PK")) {
                        // Use the user-chosen locale's currency format, which
                        // is either France or Israel.
                        myFormattedTotalAmount = mCurrencyFormat.format(mTotalAmount);
                    } else {
                        // mTotalAmount is the same (based on U.S. dollar).
                        // Use the currency format for the U.S.
                        mCurrencyFormat = NumberFormat.getCurrencyInstance(Locale.US);
                        myFormattedTotalAmount = mCurrencyFormat.format(mTotalAmount);
                    }

                    // TODO: Homework: Show the total amount string.
                    TextView total = (TextView) findViewById(R.id.total);
                    total.setText(myFormattedTotalAmount);

                    return true;
                }
                return false;
            }
        });

    }

    /**
     * Shows the Help screen.
     */
    private void showHelp() {
        // Create the intent.
        Intent helpIntent = new Intent(this, HelpActivity.class);
        // Start the HelpActivity.
        startActivity(helpIntent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle options menu item clicks here.
        switch (item.getItemId()) {
            case R.id.action_help:
                showHelp();
                return true;
            case R.id.action_language:
                Intent languageIntent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
                startActivity(languageIntent);
                return true;
            default:
                // Do nothing
        }
        return super.onOptionsItemSelected(item);
    }
}
